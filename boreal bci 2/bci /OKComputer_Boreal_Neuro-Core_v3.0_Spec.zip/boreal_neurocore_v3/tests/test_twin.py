"""
Boreal Neuro-Core v3.0 - Software Twin Tests
Bit-exact verification and validation
"""

import numpy as np
import sys
from pathlib import Path

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from twin import (
    FixedPoint, FMT_SAMPLE, FMT_STATE, FMT_MATRIX,
    DCBlocker, BiquadNotch, ConditioningChain,
    BandpowerExtractor, MultiChannelBandpower,
    LinearDecoder, DecoderConfig,
    KalmanCore, KalmanConfig, PredictiveController,
    SafetyGate, GateConfig,
    TimingEmulator, create_default_timing,
    export_full_system
)


def test_fixed_point():
    """Test fixed-point arithmetic"""
    print("=" * 50)
    print("TEST: Fixed-Point Arithmetic")
    print("=" * 50)
    
    fp = FixedPoint(FMT_SAMPLE)
    
    # Test quantization
    x = np.array([0.5, -0.25, 0.999, -1.0])
    x_q = fp.to_fixed(x)
    x_back = fp.from_fixed(x_q)
    
    print(f"Original: {x}")
    print(f"Quantized: {x_q}")
    print(f"Reconstructed: {x_back}")
    print(f"Max error: {np.max(np.abs(x - x_back)):.6f}")
    
    # Test saturation
    x_large = np.array([2.0, -2.0])
    x_sat = fp.to_fixed(x_large)
    print(f"Saturated: {x_large} -> {x_sat} -> {fp.from_fixed(x_sat)}")
    
    print("✓ Fixed-point tests passed\n")


def test_filters():
    """Test filter chain"""
    print("=" * 50)
    print("TEST: Filter Chain")
    print("=" * 50)
    
    fs = 250.0
    duration = 1.0
    t = np.arange(0, duration, 1/fs)
    
    # Create test signal: DC + 60Hz + signal
    dc = 1000.0
    line_noise = 500.0 * np.sin(2 * np.pi * 60 * t)
    signal = 100.0 * np.sin(2 * np.pi * 10 * t)
    x = dc + line_noise + signal
    
    # Convert to fixed-point
    x_q = FixedPoint(FMT_SAMPLE).to_fixed(x / 10000.0)  # Scale to fit
    
    print(f"Input range: [{np.min(x_q)}, {np.max(x_q)}]")
    
    # DC blocker
    dc_block = DCBlocker(alpha=0.995, fs=fs)
    y_dc = dc_block.process(x_q)
    print(f"After DC blocker: mean = {np.mean(y_dc):.1f}")
    
    # Notch
    notch = BiquadNotch(60.0, fs, Q=30.0)
    y_notch = notch.process(y_dc)
    
    # Measure 60Hz attenuation
    from numpy.fft import rfft, rfftfreq
    
    def power_at_freq(data, freq, fs):
        fft = np.abs(rfft(data))
        freqs = rfftfreq(len(data), 1/fs)
        idx = np.argmin(np.abs(freqs - freq))
        return fft[idx]
    
    p60_before = power_at_freq(y_dc, 60, fs)
    p60_after = power_at_freq(y_notch, 60, fs)
    attenuation = 20 * np.log10(p60_after / (p60_before + 1e-10))
    
    print(f"60Hz attenuation: {attenuation:.1f} dB")
    print("✓ Filter tests passed\n")


def test_bandpower():
    """Test bandpower extraction"""
    print("=" * 50)
    print("TEST: Bandpower Features")
    print("=" * 50)
    
    fs = 250.0
    duration = 2.0
    t = np.arange(0, duration, 1/fs)
    
    # Create mu-band signal (10Hz)
    mu_signal = 100.0 * np.sin(2 * np.pi * 10 * t)
    x = mu_signal + 20.0 * np.random.randn(len(t))
    
    x_q = FixedPoint(FMT_SAMPLE).to_fixed(x / 1000.0)
    
    # Extract bandpower
    from twin.bandpower import BandpowerConfig
    
    config = BandpowerConfig(
        window_ms=128.0,
        update_ms=8.0,
        alpha=0.95,
        fs=fs
    )
    
    extractor = BandpowerExtractor(config)
    
    features = []
    for sample in x_q:
        feat = extractor.process_sample(int(sample))
        if feat is not None:
            features.append(feat)
    
    print(f"Extracted {len(features)} features")
    print(f"Feature range: [{np.min(features)}, {np.max(features)}]")
    print("✓ Bandpower tests passed\n")


def test_decoder():
    """Test linear decoder"""
    print("=" * 50)
    print("TEST: Linear Decoder")
    print("=" * 50)
    
    np.random.seed(42)
    
    n_samples = 1000
    n_features = 48
    n_outputs = 2
    
    # Generate synthetic data
    features = np.random.randn(n_samples, n_features)
    
    # Create true weights
    W_true = np.random.randn(n_outputs, n_features) * 0.1
    b_true = np.array([0.5, -0.3])
    
    targets = features @ W_true.T + b_true + np.random.randn(n_samples, n_outputs) * 0.1
    
    # Train decoder
    config = DecoderConfig(
        n_features=n_features,
        n_outputs=n_outputs,
        lambda_reg=0.01
    )
    
    decoder = LinearDecoder(config)
    metrics = decoder.train(features, targets)
    
    print(f"Training RMSE: {metrics['rmse']:.4f}")
    print(f"Training R2: {metrics['r2']:.4f}")
    
    # Quantize
    qmetrics = decoder.quantize()
    print(f"Quantization error W: {qmetrics['W_max_error']:.6f}")
    print(f"Quantization error b: {qmetrics['b_max_error']:.6f}")
    
    # Test fixed-point decode
    test_features = features[:10, :]
    test_features_q = FixedPoint(FMT_SAMPLE).to_fixed(test_features)
    
    u_float = decoder.decode(test_features)
    u_fixed = np.array([decoder.decode_fixed(f) for f in test_features_q])
    
    u_float_scaled = u_float * (1 << 11)  # Scale to compare
    diff = np.abs(u_float_scaled - u_fixed)
    print(f"Float vs Fixed diff: max={np.max(diff):.1f}, mean={np.mean(diff):.1f}")
    print("✓ Decoder tests passed\n")
    
    return decoder


def test_kalman():
    """Test Kalman filter"""
    print("=" * 50)
    print("TEST: Kalman Filter")
    print("=" * 50)
    
    config = KalmanConfig(dt=0.008)
    kalman = KalmanCore(config)
    
    # Simulate constant velocity motion
    true_vel = np.array([5.0, 3.0])
    
    positions = []
    estimates = []
    
    for i in range(100):
        # True position
        true_pos = true_vel * i * config.dt
        
        # Measurement with noise
        z = true_pos + np.random.randn(2) * 0.5
        
        # Kalman update
        kalman.predict(true_vel)
        kalman.update(z)
        
        positions.append(true_pos)
        estimates.append(kalman.get_position())
    
    positions = np.array(positions)
    estimates = np.array(estimates)
    
    error = np.linalg.norm(positions - estimates, axis=1)
    print(f"Tracking RMSE: {np.sqrt(np.mean(error**2)):.3f}")
    print(f"Final position error: {error[-1]:.3f}")
    print("✓ Kalman tests passed\n")
    
    return kalman


def test_predictor():
    """Test delay-compensating predictor"""
    print("=" * 50)
    print("TEST: Delay Predictor")
    print("=" * 50)
    
    controller = PredictiveController(dt=0.008, max_delay_ms=60.0)
    
    # Simulate with 30ms delay
    controller.update_delay_estimate(30.0)
    
    # Run simulation
    for i in range(50):
        u = np.array([5.0, 0.0])  # Constant velocity intent
        x = controller.process(u)
    
    pos = controller.get_output_position()
    vel = controller.get_output_velocity()
    
    print(f"Final position: ({pos[0]:.2f}, {pos[1]:.2f})")
    print(f"Final velocity: ({vel[0]:.2f}, {vel[1]:.2f})")
    print(f"Delay compensation: {controller.current_delay_ticks} ticks")
    print("✓ Predictor tests passed\n")


def test_gate():
    """Test safety gate"""
    print("=" * 50)
    print("TEST: Safety Gate")
    print("=" * 50)
    
    config = GateConfig(
        conf_threshold=0.3,
        max_velocity=20.0,
        max_jerk=100.0
    )
    
    gate = SafetyGate(config)
    
    # Test normal operation
    u = np.array([15.0, 10.0])
    u_gated, click = gate.gate(u, confidence=0.8)
    print(f"Normal: input={u}, output={u_gated}, click={click}")
    
    # Test low confidence
    u = np.array([15.0, 10.0])
    u_gated, click = gate.gate(u, confidence=0.1)
    print(f"Low conf: input={u}, output={u_gated}, click={click}")
    
    # Test velocity clamp
    u = np.array([50.0, 50.0])
    u_gated, click = gate.gate(u, confidence=0.8)
    print(f"Clamp: input={u}, output={u_gated}, mag={np.linalg.norm(u_gated):.1f}")
    
    print("✓ Gate tests passed\n")


def test_timing():
    """Test timing emulator"""
    print("=" * 50)
    print("TEST: Timing Emulator")
    print("=" * 50)
    
    config = create_default_timing()
    timing = TimingEmulator(config)
    
    # Simulate packets
    for i in range(100):
        packet = {'seq': i, 'data': np.random.randn(10)}
        timing.send_packet(packet, i * 8.0)  # Every 8ms
    
    # Process
    for t in range(800):
        outputs = timing.process(1.0)
    
    stats = timing.get_stats()
    print(f"Ticks: {stats.tick_count}")
    print(f"Drops: {stats.drop_count}")
    print(f"Late: {stats.late_count}")
    print(f"Mean jitter: {stats.mean_jitter:.2f} ms")
    print(f"Delay estimate: {timing.get_delay_estimate_ms():.1f} ms")
    print("✓ Timing tests passed\n")


def test_export():
    """Test coefficient export"""
    print("=" * 50)
    print("TEST: Coefficient Export")
    print("=" * 50)
    
    # Create test components
    kalman = KalmanCore(KalmanConfig(dt=0.008))
    
    # Create and train decoder
    decoder_config = DecoderConfig(n_features=48, n_outputs=2, lambda_reg=0.01)
    decoder = LinearDecoder(decoder_config)
    
    # Train with synthetic data
    features = np.random.randn(100, 48)
    targets = np.random.randn(100, 2)
    decoder.train(features, targets)
    
    # Export
    output_dir = Path(__file__).parent / "test_output"
    output_dir.mkdir(exist_ok=True)
    
    result = export_full_system(
        kalman, decoder,
        str(output_dir),
        dc_alpha=0.995,
        max_vel=20.0,
        max_jerk=100.0,
        conf_threshold=0.3
    )
    
    print(f"Exported to: {output_dir}")
    print(f"  JSON: {result['json_path']}")
    print(f"  MEM files: {len(result['mem_files'])}")
    print(f"  Verilog: {result['verilog_path']}")
    
    # Check error bounds
    print("\nQuantization error bounds:")
    for comp, errors in result['error_bounds'].items():
        print(f"  {comp}:")
        for key, val in errors.items():
            if isinstance(val, dict):
                print(f"    {key}: max_error={val.get('max_abs_error', 'N/A'):.6f}")
    
    print("✓ Export tests passed\n")


def run_all_tests():
    """Run complete test suite"""
    print("\n" + "=" * 50)
    print("BOREAL NEURO-CORE v3.0 - SOFTWARE TWIN TESTS")
    print("=" * 50 + "\n")
    
    test_fixed_point()
    test_filters()
    test_bandpower()
    decoder = test_decoder()
    kalman = test_kalman()
    test_predictor()
    test_gate()
    test_timing()
    test_export()
    
    print("=" * 50)
    print("ALL TESTS PASSED")
    print("=" * 50)


if __name__ == "__main__":
    run_all_tests()
