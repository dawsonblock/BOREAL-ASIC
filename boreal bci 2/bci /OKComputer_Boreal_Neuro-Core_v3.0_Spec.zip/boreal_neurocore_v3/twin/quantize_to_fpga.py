"""
Boreal Neuro-Core v3.0 - Coefficient Export Pipeline
Floating-point to fixed-point conversion with error bounds verification

Exports quantized coefficients for FPGA ROM initialization
"""

import numpy as np
import json
from typing import Dict, List, Tuple, Any
from dataclasses import dataclass
from pathlib import Path

from .fixed_point import (
    FixedPoint, FixedFormat,
    FMT_SAMPLE, FMT_STATE, FMT_MATRIX, FMT_COV,
    quantize_matrix, quantize_vector, compute_quantization_error
)
from .kalman import KalmanCore
from .decoder import LinearDecoder


@dataclass
class CoefficientSet:
    """Complete coefficient set for FPGA"""
    # Kalman matrices
    A_q214: List[List[int]]      # State transition Q2.14
    B_q214: List[List[int]]      # Control input Q2.14
    H_q214: List[List[int]]      # Measurement Q2.14
    Q_q610: List[List[int]]      # Process noise Q6.10
    R_q610: List[List[int]]      # Measurement noise Q6.10
    
    # Decoder weights
    W_q511: List[List[int]]      # Decoder weights Q5.11
    b_q511: List[int]            # Decoder bias Q5.11
    
    # Filter coefficients
    dc_alpha_q115: int           # DC blocker alpha Q1.15
    notch_b_q115: List[int]      # Notch b coefficients Q1.15
    notch_a_q115: List[int]      # Notch a coefficients Q1.15
    
    # Gate parameters
    max_vel_q511: int            # Max velocity Q5.11
    max_jerk_q511: int           # Max jerk Q5.11
    conf_threshold_q115: int     # Confidence threshold Q1.15
    
    # Metadata
    version: str = "3.0"
    timestamp: str = ""


class CoefficientExporter:
    """
    Export all coefficients from trained models to FPGA-ready format
    """
    
    def __init__(self):
        self.coeffs = {}
        self.error_bounds = {}
    
    def export_kalman(self, kalman: KalmanCore) -> dict:
        """Export Kalman filter coefficients"""
        coeffs = {
            'A_q214': kalman.A_q.tolist(),
            'B_q214': kalman.B_q.tolist(),
            'H_q214': kalman.H_q.tolist(),
            'Q_q610': kalman.Q_q.tolist(),
            'R_q610': kalman.R_q.tolist(),
            'dt': kalman.dt
        }
        
        # Compute error bounds
        self.error_bounds['kalman'] = {
            'A': compute_quantization_error(kalman.A, kalman.A_q, FMT_MATRIX),
            'B': compute_quantization_error(kalman.B, kalman.B_q, FMT_MATRIX),
            'Q': compute_quantization_error(kalman.Q, kalman.Q_q, FMT_COV),
            'R': compute_quantization_error(kalman.R, kalman.R_q, FMT_COV)
        }
        
        self.coeffs['kalman'] = coeffs
        return coeffs
    
    def export_decoder(self, decoder: LinearDecoder) -> dict:
        """Export decoder coefficients"""
        if decoder.W_q is None:
            decoder.quantize()
        
        coeffs = {
            'W_q511': decoder.W_q.tolist(),
            'b_q511': decoder.b_q.tolist(),
            'n_features': decoder.cfg.n_features,
            'n_outputs': decoder.cfg.n_outputs
        }
        
        # Error bounds
        self.error_bounds['decoder'] = {
            'W': compute_quantization_error(decoder.W, decoder.W_q, FMT_STATE),
            'b': compute_quantization_error(decoder.b, decoder.b_q, FMT_STATE)
        }
        
        self.coeffs['decoder'] = coeffs
        return coeffs
    
    def export_filters(self, dc_alpha: float = 0.995,
                       notch_b: np.ndarray = None,
                       notch_a: np.ndarray = None) -> dict:
        """Export filter coefficients"""
        fp = FixedPoint(FMT_SAMPLE)
        
        coeffs = {
            'dc_alpha_q115': int(fp.to_fixed(dc_alpha)),
            'notch_b_q115': notch_b.tolist() if notch_b is not None else [32767, -65536, 32767],
            'notch_a_q115': notch_a.tolist() if notch_a is not None else [32767, -65536, 32767]
        }
        
        self.coeffs['filters'] = coeffs
        return coeffs
    
    def export_gate_params(self, max_vel: float = 20.0,
                          max_jerk: float = 100.0,
                          conf_threshold: float = 0.3) -> dict:
        """Export gate policy parameters"""
        fp_state = FixedPoint(FMT_STATE)
        fp_sample = FixedPoint(FMT_SAMPLE)
        
        coeffs = {
            'max_vel_q511': int(fp_state.to_fixed(max_vel)),
            'max_jerk_q511': int(fp_state.to_fixed(max_jerk)),
            'conf_threshold_q115': int(fp_sample.to_fixed(conf_threshold))
        }
        
        self.coeffs['gate'] = coeffs
        return coeffs
    
    def generate_mem_files(self, output_dir: str) -> List[str]:
        """
        Generate .mem files for FPGA $readmemh
        
        Returns:
            List of generated file paths
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        files = []
        
        # Kalman matrices
        if 'kalman' in self.coeffs:
            k = self.coeffs['kalman']
            for name, data in [
                ('A_q214', k['A_q214']),
                ('B_q214', k['B_q214']),
                ('H_q214', k['H_q214']),
                ('Q_q610', k['Q_q610']),
                ('R_q610', k['R_q610'])
            ]:
                path = output_path / f"{name}.mem"
                self._write_mem_file(path, data)
                files.append(str(path))
        
        # Decoder weights
        if 'decoder' in self.coeffs:
            d = self.coeffs['decoder']
            path = output_path / "W_q511.mem"
            self._write_mem_file(path, d['W_q511'])
            files.append(str(path))
            
            path = output_path / "b_q511.mem"
            self._write_mem_file(path, [[b] for b in d['b_q511']])
            files.append(str(path))
        
        return files
    
    def _write_mem_file(self, path: Path, data: List, width: int = 16):
        """Write data to .mem file in hexadecimal"""
        with open(path, 'w') as f:
            if isinstance(data[0], list):
                # 2D array - flatten row-major
                for row in data:
                    for val in row:
                        # Handle negative numbers (2's complement)
                        if val < 0:
                            val = (1 << width) + val
                        f.write(f"{val:0{width//4}X}\n")
            else:
                # 1D array
                for val in data:
                    if val < 0:
                        val = (1 << width) + val
                    f.write(f"{val:0{width//4}X}\n")
    
    def export_json(self, path: str) -> dict:
        """Export complete coefficient set as JSON"""
        from datetime import datetime
        
        export = {
            'version': '3.0',
            'timestamp': datetime.now().isoformat(),
            'coefficients': self.coeffs,
            'error_bounds': self.error_bounds,
            'formats': {
                'Q115': {'int': 1, 'frac': 15, 'range': [-1, 1]},
                'Q511': {'int': 5, 'frac': 11, 'range': [-32, 32]},
                'Q214': {'int': 2, 'frac': 14, 'range': [-2, 2]},
                'Q610': {'int': 6, 'frac': 10, 'range': [-64, 64]}
            }
        }
        
        with open(path, 'w') as f:
            json.dump(export, f, indent=2)
        
        return export
    
    def generate_verilog_params(self, path: str):
        """Generate Verilog parameter file"""
        lines = [
            "// Boreal Neuro-Core v3.0 - Auto-generated parameters",
            f"// Generated: {np.datetime64('now')}",
            ""
        ]
        
        if 'kalman' in self.coeffs:
            k = self.coeffs['kalman']
            lines.append("// Kalman matrices (Q2.14)")
            lines.append(self._matrix_to_verilog_param('KALMAN_A', k['A_q214']))
            lines.append(self._matrix_to_verilog_param('KALMAN_B', k['B_q214']))
            lines.append("")
        
        if 'decoder' in self.coeffs:
            d = self.coeffs['decoder']
            lines.append("// Decoder weights (Q5.11)")
            lines.append(f"localparam DECODER_N_FEATURES = {d['n_features']};")
            lines.append(f"localparam DECODER_N_OUTPUTS = {d['n_outputs']};")
            lines.append(self._matrix_to_verilog_param('DECODER_W', d['W_q511']))
            lines.append(self._array_to_verilog_param('DECODER_B', d['b_q511']))
            lines.append("")
        
        with open(path, 'w') as f:
            f.write('\n'.join(lines))
    
    def _matrix_to_verilog_param(self, name: str, matrix: List[List[int]]) -> str:
        """Convert matrix to Verilog localparam"""
        rows = len(matrix)
        cols = len(matrix[0]) if rows > 0 else 0
        
        lines = [f"localparam signed [15:0] {name} [0:{rows-1}][0:{cols-1}] = '{{"]
        
        row_strs = []
        for row in matrix:
            row_str = "{" + ", ".join(str(v) for v in row) + "}"
            row_strs.append(row_str)
        
        lines.append(",\n".join("    " + r for r in row_strs))
        lines.append("};")
        
        return '\n'.join(lines)
    
    def _array_to_verilog_param(self, name: str, arr: List[int]) -> str:
        """Convert array to Verilog localparam"""
        n = len(arr)
        values = ", ".join(str(v) for v in arr)
        return f"localparam signed [15:0] {name} [0:{n-1}] = '{{{values}}};"


def export_full_system(kalman: KalmanCore,
                       decoder: LinearDecoder,
                       output_dir: str,
                       dc_alpha: float = 0.995,
                       max_vel: float = 20.0,
                       max_jerk: float = 100.0,
                       conf_threshold: float = 0.3) -> dict:
    """
    Export complete system coefficients
    
    Args:
        kalman: Trained Kalman filter
        decoder: Trained decoder
        output_dir: Output directory
        dc_alpha: DC blocker alpha
        max_vel: Max velocity
        max_jerk: Max jerk
        conf_threshold: Confidence threshold
    
    Returns:
        Export metadata
    """
    exporter = CoefficientExporter()
    
    # Export all components
    exporter.export_kalman(kalman)
    exporter.export_decoder(decoder)
    exporter.export_filters(dc_alpha=dc_alpha)
    exporter.export_gate_params(max_vel, max_jerk, conf_threshold)
    
    # Generate output files
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # JSON export
    json_path = output_path / "coeffs.json"
    exporter.export_json(str(json_path))
    
    # Memory files
    mem_files = exporter.generate_mem_files(str(output_path / "mem"))
    
    # Verilog parameters
    exporter.generate_verilog_params(str(output_path / "params.v"))
    
    return {
        'json_path': str(json_path),
        'mem_files': mem_files,
        'verilog_path': str(output_path / "params.v"),
        'error_bounds': exporter.error_bounds
    }


def verify_coefficients(json_path: str, 
                        kalman: KalmanCore = None,
                        decoder: LinearDecoder = None) -> dict:
    """
    Verify exported coefficients match original
    
    Returns:
        Verification results
    """
    with open(json_path, 'r') as f:
        exported = json.load(f)
    
    results = {'passed': True, 'errors': []}
    
    if kalman is not None and 'kalman' in exported['coefficients']:
        k_exp = exported['coefficients']['kalman']
        
        # Check A matrix
        A_exp = np.array(k_exp['A_q214'])
        if not np.allclose(A_exp, kalman.A_q):
            results['passed'] = False
            results['errors'].append("Kalman A mismatch")
    
    if decoder is not None and 'decoder' in exported['coefficients']:
        d_exp = exported['coefficients']['decoder']
        
        W_exp = np.array(d_exp['W_q511'])
        if not np.allclose(W_exp, decoder.W_q):
            results['passed'] = False
            results['errors'].append("Decoder W mismatch")
    
    return results
