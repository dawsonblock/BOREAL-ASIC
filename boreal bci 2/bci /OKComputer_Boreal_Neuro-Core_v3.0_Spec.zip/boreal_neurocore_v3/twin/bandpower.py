"""
Boreal Neuro-Core v3.0 - Bandpower Feature Extraction
Sliding window power estimation with EWMA smoothing

For each channel and band:
    P[n] = alpha * P[n-1] + (1-alpha) * y[n]^2
    feature = log(P + epsilon)

EWMA provides smooth power tracking with configurable time constant.
Log transform compresses dynamic range.
"""

import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from .fixed_point import FixedPoint, FMT_SAMPLE, FP_SAMPLE


@dataclass
class BandpowerConfig:
    """Configuration for bandpower extraction"""
    window_ms: float = 128.0      # Analysis window (ms)
    update_ms: float = 8.0        # Feature update rate (ms)
    alpha: float = 0.95           # EWMA smoothing (0-1, higher = smoother)
    eps: float = 1e-6             # Small constant for log
    fs: float = 250.0             # Sampling rate (Hz)


class BandpowerExtractor:
    """
    Single-channel bandpower extractor with EWMA smoothing
    """
    
    def __init__(self, config: BandpowerConfig = None):
        self.cfg = config or BandpowerConfig()
        
        # Compute window sizes in samples
        self.window_samples = int(self.cfg.window_ms * self.cfg.fs / 1000)
        self.update_samples = int(self.cfg.update_ms * self.cfg.fs / 1000)
        
        # Quantize alpha to Q1.15
        self.alpha_q = FP_SAMPLE.to_fixed(self.cfg.alpha)
        self.one_minus_alpha_q = FP_SAMPLE.to_fixed(1.0 - self.cfg.alpha)
        
        # Power estimate (Q6.10 format for larger range)
        self.power_q = 0  # Q6.10
        
        # Circular buffer for window
        self.buffer = np.zeros(self.window_samples, dtype=np.int16)
        self.buf_idx = 0
        self.sample_count = 0
        
        # Log LUT (computed on first use)
        self._log_lut = None
        self._log_lut_scale = 10  # Output Q format for log
    
    def _build_log_lut(self, max_input: int = 65535):
        """Build lookup table for log transform"""
        # Input: Q6.10 power values (0 to ~64)
        # Output: log2 scaled
        n_entries = max_input + 1
        lut = np.zeros(n_entries, dtype=np.int16)
        
        for i in range(1, n_entries):
            # Convert from Q6.10 to float
            power_f = i / 1024.0
            # log2 with scaling
            log_val = np.log2(power_f + self.cfg.eps)
            # Scale to Q4.12 (range roughly -8 to 8)
            lut[i] = int(np.clip(log_val * 4096, -32768, 32767))
        
        lut[0] = lut[1]  # Handle zero
        return lut
    
    def _log_lut_lookup(self, power_q: int) -> int:
        """Lookup log value from power estimate"""
        if self._log_lut is None:
            self._log_lut = self._build_log_lut()
        
        # Clamp to valid range
        idx = np.clip(power_q, 0, len(self._log_lut) - 1)
        return int(self._log_lut[idx])
    
    def reset(self):
        """Reset state"""
        self.power_q = 0
        self.buffer.fill(0)
        self.buf_idx = 0
        self.sample_count = 0
    
    def process_sample(self, x: int) -> Optional[int]:
        """
        Process single sample, return feature when window complete
        
        Args:
            x: Input sample (Q1.15)
        
        Returns:
            Log-bandpower feature (Q4.12) or None if not ready
        """
        # Store in buffer
        self.buffer[self.buf_idx] = x
        self.buf_idx = (self.buf_idx + 1) % self.window_samples
        self.sample_count += 1
        
        # Compute instantaneous power: x^2
        # Q1.15 * Q1.15 = Q2.30, shift to Q6.10
        x_sq = (x * x) >> 20  # Now in Q6.10 range
        
        # EWMA update: P = alpha * P + (1-alpha) * x^2
        # Both terms in Q6.10
        term1 = (self.alpha_q * self.power_q) >> 15  # Back to Q6.10
        term2 = (self.one_minus_alpha_q * x_sq) >> 15
        
        self.power_q = term1 + term2
        self.power_q = np.clip(self.power_q, 0, 65535)
        
        # Return feature at update rate
        if self.sample_count >= self.update_samples:
            self.sample_count = 0
            return self._log_lut_lookup(self.power_q)
        
        return None
    
    def get_power(self) -> float:
        """Get current power estimate as float"""
        return self.power_q / 1024.0


class MultiChannelBandpower:
    """
    Multi-channel, multi-band bandpower extraction
    """
    
    def __init__(self, n_channels: int, bands: List[str],
                 config: BandpowerConfig = None):
        """
        Args:
            n_channels: Number of EEG channels
            bands: List of band names (must match FilterBank)
            config: Bandpower configuration
        """
        self.n_channels = n_channels
        self.bands = bands
        self.n_bands = len(bands)
        self.cfg = config or BandpowerConfig()
        
        # Create extractor for each channel-band combination
        self.extractors = {}
        for ch in range(n_channels):
            for band in bands:
                key = (ch, band)
                self.extractors[key] = BandpowerExtractor(self.cfg)
        
        # Feature vector buffer
        self.feature_dim = n_channels * len(bands)
        self.last_features = np.zeros(self.feature_dim, dtype=np.int16)
    
    def reset(self):
        """Reset all extractors"""
        for ext in self.extractors.values():
            ext.reset()
        self.last_features.fill(0)
    
    def process_frame(self, band_data: Dict[str, np.ndarray]) -> Optional[np.ndarray]:
        """
        Process one frame of band-filtered data
        
        Args:
            band_data: Dict mapping band name to (n_channels, n_samples) array
        
        Returns:
            Feature vector (n_channels * n_bands,) or None if not ready
        """
        features_ready = False
        feature_idx = 0
        
        for ch in range(self.n_channels):
            for band in self.bands:
                key = (ch, band)
                extractor = self.extractors[key]
                
                # Process all samples for this channel-band
                samples = band_data[band][ch, :]
                result = None
                for s in samples:
                    result = extractor.process_sample(int(s))
                
                if result is not None:
                    self.last_features[feature_idx] = result
                    features_ready = True
                
                feature_idx += 1
        
        if features_ready:
            return self.last_features.copy()
        return None
    
    def get_feature_names(self) -> List[str]:
        """Get list of feature names"""
        names = []
        for ch in range(self.n_channels):
            for band in self.bands:
                names.append(f"ch{ch}_{band}")
        return names


class FeatureNormalizer:
    """
    Running statistics normalization (EWMA-based)
    z = (x - mean) / sqrt(var + eps)
    """
    
    def __init__(self, n_features: int, alpha_mean: float = 0.995,
                 alpha_var: float = 0.99):
        self.n_features = n_features
        self.alpha_mean_q = FP_SAMPLE.to_fixed(alpha_mean)
        self.alpha_var_q = FP_SAMPLE.to_fixed(alpha_var)
        self.one_minus_alpha_mean_q = FP_SAMPLE.to_fixed(1 - alpha_mean)
        self.one_minus_alpha_var_q = FP_SAMPLE.to_fixed(1 - alpha_var)
        
        # Running statistics (Q5.11 for mean, Q6.10 for var)
        self.mean_q = np.zeros(n_features, dtype=np.int32)
        self.var_q = np.ones(n_features, dtype=np.int32) * 1024  # Start at 1.0
        
        self.initialized = False
    
    def reset(self):
        """Reset statistics"""
        self.mean_q.fill(0)
        self.var_q.fill(1024)
        self.initialized = False
    
    def update(self, features: np.ndarray) -> np.ndarray:
        """
        Update running statistics and return normalized features
        
        Args:
            features: Raw features (Q4.12)
        
        Returns:
            Normalized features (Q1.15)
        """
        normalized = np.zeros(self.n_features, dtype=np.int16)
        
        for i in range(self.n_features):
            x = int(features[i])
            
            # Update mean: mu = alpha*mu + (1-alpha)*x
            term1 = (self.alpha_mean_q * self.mean_q[i]) >> 15
            term2 = (self.one_minus_alpha_mean_q * x) >> 15
            self.mean_q[i] = term1 + term2
            
            # Update variance: var = alpha*var + (1-alpha)*(x-mu)^2
            diff = x - self.mean_q[i]
            diff_sq = (diff * diff) >> 12  # Scale appropriately
            
            term1 = (self.alpha_var_q * self.var_q[i]) >> 15
            term2 = (self.one_minus_alpha_var_q * diff_sq) >> 15
            self.var_q[i] = term1 + term2
            
            # Normalize: (x - mu) / sqrt(var)
            # Approximate 1/sqrt(var) with LUT or Newton iteration
            # For now, use simple scaling
            if self.var_q[i] > 0:
                # Simplified: divide by var (not sqrt) for fixed-point
                norm_val = (diff * 1024) // max(self.var_q[i], 1)
                normalized[i] = np.clip(norm_val, -32768, 32767)
            else:
                normalized[i] = 0
        
        self.initialized = True
        return normalized
    
    def normalize(self, features: np.ndarray) -> np.ndarray:
        """Normalize using current statistics (no update)"""
        normalized = np.zeros(self.n_features, dtype=np.int16)
        
        for i in range(self.n_features):
            x = int(features[i])
            diff = x - self.mean_q[i]
            if self.var_q[i] > 0:
                norm_val = (diff * 1024) // max(self.var_q[i], 1)
                normalized[i] = np.clip(norm_val, -32768, 32767)
            else:
                normalized[i] = 0
        
        return normalized


def create_standard_bandpower(n_channels: int = 16, fs: float = 250.0) -> MultiChannelBandpower:
    """Factory for standard EEG bandpower extraction"""
    config = BandpowerConfig(
        window_ms=128.0,
        update_ms=8.0,
        alpha=0.95,
        fs=fs
    )
    return MultiChannelBandpower(n_channels, ['mu', 'beta', 'gamma'], config)
