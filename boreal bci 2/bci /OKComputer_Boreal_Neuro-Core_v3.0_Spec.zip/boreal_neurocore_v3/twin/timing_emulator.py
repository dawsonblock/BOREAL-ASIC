"""
Boreal Neuro-Core v3.0 - Timing Emulator
Simulates real-time behavior including jitter, delay, and buffer effects

Models:
- Control tick generation (fixed rate)
- Transport delay (variable, measured)
- Jitter buffer (absorbs delay variation)
- End-to-end latency measurement
"""

import numpy as np
from typing import List, Tuple, Optional, Callable
from dataclasses import dataclass, field
from collections import deque
import time


@dataclass
class TimingConfig:
    """Timing emulator configuration"""
    tick_ms: float = 8.0              # Control tick period
    nominal_delay_ms: float = 30.0    # Nominal transport delay
    jitter_ms: float = 10.0           # Delay variation (std dev)
    buffer_depth: int = 4             # Jitter buffer frames
    dropout_rate: float = 0.001       # Packet dropout probability


@dataclass
class TimingStats:
    """Timing statistics"""
    tick_count: int = 0
    jitter_samples: List[float] = field(default_factory=list)
    latency_samples: List[float] = field(default_factory=list)
    drop_count: int = 0
    late_count: int = 0
    
    @property
    def mean_jitter(self) -> float:
        return np.mean(self.jitter_samples) if self.jitter_samples else 0
    
    @property
    def std_jitter(self) -> float:
        return np.std(self.jitter_samples) if len(self.jitter_samples) > 1 else 0
    
    @property
    def mean_latency(self) -> float:
        return np.mean(self.latency_samples) if self.latency_samples else 0


class JitterBuffer:
    """
    Jitter buffer for smoothing delay variations
    Releases frames when buffer level >= threshold
    """
    
    def __init__(self, depth: int = 4, release_threshold: int = 2):
        self.depth = depth
        self.release_threshold = release_threshold
        self.buffer = deque(maxlen=depth)
        self.underflow_count = 0
    
    def reset(self):
        """Reset buffer"""
        self.buffer.clear()
        self.underflow_count = 0
    
    def push(self, frame: dict) -> bool:
        """
        Push frame into buffer
        
        Returns:
            True if accepted, False if dropped (buffer full)
        """
        if len(self.buffer) >= self.depth:
            return False
        self.buffer.append(frame)
        return True
    
    def pop(self) -> Optional[dict]:
        """
        Pop frame if available
        
        Returns:
            Frame or None if underflow
        """
        if len(self.buffer) >= self.release_threshold:
            return self.buffer.popleft()
        self.underflow_count += 1
        return None
    
    @property
    def level(self) -> int:
        """Current buffer level"""
        return len(self.buffer)


class TimingEmulator:
    """
    Emulates end-to-end timing behavior of the Boreal system
    """
    
    def __init__(self, config: TimingConfig = None):
        self.cfg = config or TimingConfig()
        
        # Jitter buffer
        self.buffer = JitterBuffer(
            depth=self.cfg.buffer_depth,
            release_threshold=2
        )
        
        # Delay estimator (exponential moving average)
        self.delay_estimate = self.cfg.nominal_delay_ms
        self.delay_alpha = 0.9
        
        # Statistics
        self.stats = TimingStats()
        
        # Simulation state
        self.current_time = 0.0
        self.next_tick_time = 0.0
        self.in_flight = []  # Packets in transit
        
        # Tick callback
        self.tick_callback = None
    
    def reset(self):
        """Reset emulator state"""
        self.buffer.reset()
        self.delay_estimate = self.cfg.nominal_delay_ms
        self.stats = TimingStats()
        self.current_time = 0.0
        self.next_tick_time = 0.0
        self.in_flight.clear()
    
    def set_tick_callback(self, callback: Callable):
        """Set callback for control ticks"""
        self.tick_callback = callback
    
    def _generate_delay(self) -> float:
        """Generate random delay with jitter"""
        delay = np.random.normal(
            self.cfg.nominal_delay_ms,
            self.cfg.jitter_ms
        )
        return max(delay, 1.0)  # Minimum 1ms
    
    def _update_delay_estimate(self, measured: float):
        """Update delay estimate with new measurement"""
        self.delay_estimate = (
            self.delay_alpha * self.delay_estimate +
            (1 - self.delay_alpha) * measured
        )
    
    def send_packet(self, packet: dict, timestamp: float) -> bool:
        """
        Send packet through emulated transport
        
        Args:
            packet: Data packet
            timestamp: Send timestamp
        
        Returns:
            True if sent (not dropped)
        """
        if np.random.random() < self.cfg.dropout_rate:
            self.stats.drop_count += 1
            return False
        
        delay = self._generate_delay()
        arrival_time = timestamp + delay
        
        self.in_flight.append({
            'packet': packet,
            'sent': timestamp,
            'arrival': arrival_time,
            'delay': delay
        })
        
        return True
    
    def process(self, dt: float) -> List[dict]:
        """
        Process time step, return any ready control outputs
        
        Args:
            dt: Time step (ms)
        
        Returns:
            List of output frames
        """
        self.current_time += dt
        outputs = []
        
        # Process arrivals
        arrived = [p for p in self.in_flight if p['arrival'] <= self.current_time]
        self.in_flight = [p for p in self.in_flight if p['arrival'] > self.current_time]
        
        for arr in arrived:
            # Update delay estimate
            self._update_delay_estimate(arr['delay'])
            self.stats.jitter_samples.append(arr['delay'])
            
            # Add to jitter buffer
            arr['packet']['delay_measured'] = arr['delay']
            arr['packet']['delay_estimate'] = self.delay_estimate
            self.buffer.push(arr['packet'])
        
        # Generate control ticks
        while self.next_tick_time <= self.current_time:
            self.stats.tick_count += 1
            
            # Try to get frame from buffer
            frame = self.buffer.pop()
            
            if frame is not None:
                # Compute latency
                latency = self.current_time - frame.get('timestamp', self.current_time)
                self.stats.latency_samples.append(latency)
                
                # Add timing info
                frame['tick_time'] = self.next_tick_time
                frame['latency'] = latency
                frame['delay_estimate'] = self.delay_estimate
                
                outputs.append(frame)
            else:
                self.stats.late_count += 1
            
            # Callback
            if self.tick_callback:
                self.tick_callback(self.next_tick_time, frame)
            
            self.next_tick_time += self.cfg.tick_ms
        
        return outputs
    
    def get_delay_estimate_ms(self) -> float:
        """Get current delay estimate for predictor"""
        return self.delay_estimate
    
    def get_delay_ticks(self) -> int:
        """Get delay in control ticks"""
        return int(self.delay_estimate / self.cfg.tick_ms)
    
    def get_stats(self) -> TimingStats:
        """Get timing statistics"""
        return self.stats


class RealTimeLoop:
    """
    Simulates the complete real-time control loop
    """
    
    def __init__(self, 
                 signal_source: Callable,
                 processor: Callable,
                 timing_config: TimingConfig = None):
        """
        Args:
            signal_source: Callable that returns (timestamp, samples)
            processor: Callable that processes samples and returns control
            timing_config: Timing configuration
        """
        self.signal_source = signal_source
        self.processor = processor
        self.timing = TimingEmulator(timing_config)
        
        self.running = False
        self.output_log = []
    
    def reset(self):
        """Reset loop"""
        self.timing.reset()
        self.output_log.clear()
    
    def run(self, duration_ms: float, dt_ms: float = 1.0) -> List[dict]:
        """
        Run simulation
        
        Args:
            duration_ms: Simulation duration
            dt_ms: Simulation time step
        
        Returns:
            Output log
        """
        self.reset()
        self.running = True
        
        elapsed = 0.0
        while elapsed < duration_ms and self.running:
            # Get signal
            timestamp, samples = self.signal_source(elapsed)
            
            # Process
            control = self.processor(samples)
            
            # Create packet
            packet = {
                'timestamp': elapsed,
                'control': control,
                'samples': samples
            }
            
            # Send through timing emulator
            self.timing.send_packet(packet, elapsed)
            
            # Process timing
            outputs = self.timing.process(dt_ms)
            self.output_log.extend(outputs)
            
            elapsed += dt_ms
        
        self.running = False
        return self.output_log
    
    def stop(self):
        """Stop simulation"""
        self.running = False
    
    def get_timing_stats(self) -> dict:
        """Get comprehensive timing statistics"""
        stats = self.timing.get_stats()
        
        return {
            'tick_count': stats.tick_count,
            'drop_count': stats.drop_count,
            'late_count': stats.late_count,
            'mean_jitter_ms': stats.mean_jitter,
            'std_jitter_ms': stats.std_jitter,
            'mean_latency_ms': stats.mean_latency,
            'delay_estimate_ms': self.timing.get_delay_estimate_ms(),
            'delay_ticks': self.timing.get_delay_ticks()
        }


def create_default_timing() -> TimingConfig:
    """Factory for standard timing configuration"""
    return TimingConfig(
        tick_ms=8.0,
        nominal_delay_ms=30.0,
        jitter_ms=8.0,
        buffer_depth=4,
        dropout_rate=0.001
    )


def create_low_latency_timing() -> TimingConfig:
    """Factory for low-latency (wired) configuration"""
    return TimingConfig(
        tick_ms=4.0,
        nominal_delay_ms=5.0,
        jitter_ms=1.0,
        buffer_depth=2,
        dropout_rate=0.0
    )


def create_wireless_timing() -> TimingConfig:
    """Factory for wireless (high jitter) configuration"""
    return TimingConfig(
        tick_ms=8.0,
        nominal_delay_ms=50.0,
        jitter_ms=20.0,
        buffer_depth=8,
        dropout_rate=0.005
    )
