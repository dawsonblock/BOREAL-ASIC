"""
Boreal Neuro-Core v3.0 - Software Twin
Bit-accurate fixed-point implementation for validation and coefficient generation
"""

from .fixed_point import (
    FixedPoint, FixedFormat,
    FMT_SAMPLE, FMT_STATE, FMT_MATRIX, FMT_COV,
    FP_SAMPLE, FP_STATE, FP_MATRIX, FP_COV,
    quantize_matrix, quantize_vector,
    check_overflow, compute_quantization_error
)

from .filters import (
    DCBlocker,
    BiquadNotch,
    BandpassBiquad,
    FilterBank,
    ConditioningChain,
    create_eeg_conditioning
)

from .bandpower import (
    BandpowerConfig,
    BandpowerExtractor,
    MultiChannelBandpower,
    FeatureNormalizer,
    create_standard_bandpower
)

from .decoder import (
    DecoderConfig,
    LinearDecoder,
    LMSAdaptiveDecoder,
    train_decoder_from_data
)

from .kalman import (
    KalmanConfig,
    KalmanCore,
    DelayPredictor,
    PredictiveController
)

from .gate import (
    GateConfig,
    SafetyGate,
    ConfidenceEstimator
)

from .timing_emulator import (
    TimingConfig,
    TimingStats,
    JitterBuffer,
    TimingEmulator,
    RealTimeLoop,
    create_default_timing,
    create_low_latency_timing,
    create_wireless_timing
)

from .quantize_to_fpga import (
    CoefficientSet,
    CoefficientExporter,
    export_full_system,
    verify_coefficients
)

__version__ = "3.0"
__all__ = [
    # Fixed-point
    'FixedPoint', 'FixedFormat',
    'FMT_SAMPLE', 'FMT_STATE', 'FMT_MATRIX', 'FMT_COV',
    'FP_SAMPLE', 'FP_STATE', 'FP_MATRIX', 'FP_COV',
    'quantize_matrix', 'quantize_vector',
    'check_overflow', 'compute_quantization_error',
    
    # Filters
    'DCBlocker', 'BiquadNotch', 'BandpassBiquad', 'FilterBank',
    'ConditioningChain', 'create_eeg_conditioning',
    
    # Features
    'BandpowerConfig', 'BandpowerExtractor', 'MultiChannelBandpower',
    'FeatureNormalizer', 'create_standard_bandpower',
    
    # Decoder
    'DecoderConfig', 'LinearDecoder', 'LMSAdaptiveDecoder',
    'train_decoder_from_data',
    
    # Kalman
    'KalmanConfig', 'KalmanCore', 'DelayPredictor', 'PredictiveController',
    
    # Gate
    'GateConfig', 'SafetyGate', 'ConfidenceEstimator',
    
    # Timing
    'TimingConfig', 'TimingStats', 'JitterBuffer', 'TimingEmulator',
    'RealTimeLoop', 'create_default_timing', 'create_low_latency_timing',
    'create_wireless_timing',
    
    # Export
    'CoefficientSet', 'CoefficientExporter', 'export_full_system', 'verify_coefficients'
]
