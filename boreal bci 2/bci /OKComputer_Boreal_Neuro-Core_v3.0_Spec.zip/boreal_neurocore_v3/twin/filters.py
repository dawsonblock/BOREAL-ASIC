"""
Boreal Neuro-Core v3.0 - Streaming Digital Filters
Fixed-point IIR filters for signal conditioning

Filters implemented:
- DC blocker: 1st-order high-pass IIR
- Notch: 2nd-order biquad (50/60 Hz + harmonics)
- Bandpass: Biquad cascade or FIR (configurable)

All filters use Q1.15 for input/output, internal accumulators are 32-bit.
"""

import numpy as np
from typing import List, Tuple, Optional
from dataclasses import dataclass
from .fixed_point import FixedPoint, FMT_SAMPLE, FP_SAMPLE, quantize_vector


@dataclass
class FilterState:
    """Filter state for streaming operation"""
    x_hist: np.ndarray   # Input history
    y_hist: np.ndarray   # Output history
    

class DCBlocker:
    """
    1st-order IIR high-pass filter for DC removal
    y[n] = x[n] - x[n-1] + alpha * y[n-1]
    
    Alpha typically 0.995-0.9999 (closer to 1 = lower cutoff)
    Cutoff ≈ (1-alpha) * fs / (2*pi)
    """
    
    def __init__(self, alpha: float = 0.995, fs: float = 250.0):
        self.alpha = alpha
        self.fs = fs
        
        # Quantize alpha to Q1.15
        self.alpha_q = FP_SAMPLE.to_fixed(alpha)
        
        # State: x[n-1], y[n-1]
        self.x_prev = 0
        self.y_prev = 0
        
        # Compute actual cutoff
        self.cutoff_hz = (1 - alpha) * fs / (2 * np.pi)
    
    def reset(self):
        """Reset filter state"""
        self.x_prev = 0
        self.y_prev = 0
    
    def process_sample(self, x: int) -> int:
        """Process single sample in fixed-point"""
        # y = x - x_prev + (alpha * y_prev) >> 15
        # All values are Q1.15
        
        diff = x - self.x_prev  # Q1.15 - Q1.15 = Q2.15 (in 32-bit)
        
        # alpha * y_prev: Q1.15 * Q1.15 = Q2.30
        feedback = (self.alpha_q * self.y_prev) >> 15  # Back to Q1.15
        
        # Sum and saturate to 16-bit
        y = diff + feedback
        y = np.clip(y, -32768, 32767).astype(np.int16)
        
        # Update state
        self.x_prev = x
        self.y_prev = y
        
        return int(y)
    
    def process(self, x: np.ndarray) -> np.ndarray:
        """Process array of samples"""
        result = np.zeros_like(x, dtype=np.int16)
        for i, xi in enumerate(x):
            result[i] = self.process_sample(int(xi))
        return result
    
    def process_float(self, x: np.ndarray) -> np.ndarray:
        """Process float array (for testing/comparison)"""
        x_q = FP_SAMPLE.to_fixed(x)
        y_q = self.process(x_q)
        return FP_SAMPLE.from_fixed(y_q)


class BiquadNotch:
    """
    2nd-order biquad notch filter
    Standard form: y[n] = b0*x[n] + b1*x[n-1] + b2*x[n-2] 
                           - a1*y[n-1] - a2*y[n-2]
    
    Coefficients designed for notch at specific frequency.
    """
    
    def __init__(self, f0: float, fs: float, Q: float = 30.0):
        """
        Args:
            f0: Notch frequency (Hz)
            fs: Sampling rate (Hz)
            Q: Quality factor (higher = narrower notch)
        """
        self.f0 = f0
        self.fs = fs
        self.Q = Q
        
        # Design analog prototype and bilinear transform
        w0 = 2 * np.pi * f0 / fs
        alpha = np.sin(w0) / (2 * Q)
        
        # Notch coefficients
        b0 = 1.0
        b1 = -2 * np.cos(w0)
        b2 = 1.0
        a0 = 1.0 + alpha
        a1 = -2 * np.cos(w0)
        a2 = 1.0 - alpha
        
        # Normalize by a0
        self.b = np.array([b0, b1, b2]) / a0
        self.a = np.array([a0, a1, a2]) / a0
        
        # Quantize to Q2.14 for coefficients (need >1 range)
        self.b_q = quantize_vector(self.b, FMT_SAMPLE)
        self.a_q = quantize_vector(self.a[1:], FMT_SAMPLE)  # a[1], a[2]
        
        # State: x[n-1], x[n-2], y[n-1], y[n-2]
        self.x_hist = np.zeros(2, dtype=np.int32)
        self.y_hist = np.zeros(2, dtype=np.int32)
    
    def reset(self):
        """Reset filter state"""
        self.x_hist.fill(0)
        self.y_hist.fill(0)
    
    def process_sample(self, x: int) -> int:
        """Process single sample"""
        # y = b0*x + b1*x1 + b2*x2 - a1*y1 - a2*y2
        # All in Q1.15, accumulators 32-bit
        
        acc = self.b_q[0] * x
        acc += self.b_q[1] * self.x_hist[0]
        acc += self.b_q[2] * self.x_hist[1]
        acc -= self.a_q[0] * self.y_hist[0]
        acc -= self.a_q[1] * self.y_hist[1]
        
        # Scale back from Q2.30 to Q1.15
        y = (acc + (1 << 14)) >> 15  # Round then shift
        y = np.clip(y, -32768, 32767).astype(np.int16)
        
        # Update state
        self.x_hist[1] = self.x_hist[0]
        self.x_hist[0] = x
        self.y_hist[1] = self.y_hist[0]
        self.y_hist[0] = y
        
        return int(y)
    
    def process(self, x: np.ndarray) -> np.ndarray:
        """Process array of samples"""
        result = np.zeros_like(x, dtype=np.int16)
        for i, xi in enumerate(x):
            result[i] = self.process_sample(int(xi))
        return result


class BandpassBiquad:
    """
    Bandpass filter using biquad cascade
    Default: 4th-order Butterworth (2 biquad sections)
    """
    
    def __init__(self, lowcut: float, highcut: float, fs: float, order: int = 4):
        """
        Args:
            lowcut: Lower cutoff frequency (Hz)
            highcut: Upper cutoff frequency (Hz)
            fs: Sampling rate (Hz)
            order: Filter order (must be even for biquad)
        """
        self.lowcut = lowcut
        self.highcut = highcut
        self.fs = fs
        self.order = order
        
        # Design Butterworth bandpass
        from scipy import signal
        nyq = fs / 2.0
        low = lowcut / nyq
        high = highcut / nyq
        
        sos = signal.butter(order // 2, [low, high], btype='band', output='sos')
        
        self.n_sections = len(sos)
        self.sections = []
        
        for s in sos:
            b = s[:3]
            a = s[3:]
            
            # Quantize coefficients
            b_q = quantize_vector(b, FMT_SAMPLE)
            a_q = quantize_vector(a[1:], FMT_SAMPLE)  # a[1], a[2]
            
            self.sections.append({
                'b_q': b_q,
                'a_q': a_q,
                'x_hist': np.zeros(2, dtype=np.int32),
                'y_hist': np.zeros(2, dtype=np.int32)
            })
    
    def reset(self):
        """Reset all sections"""
        for sec in self.sections:
            sec['x_hist'].fill(0)
            sec['y_hist'].fill(0)
    
    def process_sample(self, x: int) -> int:
        """Process through cascade"""
        y = x
        for sec in self.sections:
            acc = sec['b_q'][0] * y
            acc += sec['b_q'][1] * sec['x_hist'][0]
            acc += sec['b_q'][2] * sec['x_hist'][1]
            acc -= sec['a_q'][0] * sec['y_hist'][0]
            acc -= sec['a_q'][1] * sec['y_hist'][1]
            
            y = (acc + (1 << 14)) >> 15
            y = np.clip(y, -32768, 32767).astype(np.int16)
            
            # Update state
            sec['x_hist'][1] = sec['x_hist'][0]
            sec['x_hist'][0] = y
            sec['y_hist'][1] = sec['y_hist'][0]
            sec['y_hist'][0] = y
        
        return int(y)
    
    def process(self, x: np.ndarray) -> np.ndarray:
        """Process array"""
        result = np.zeros_like(x, dtype=np.int16)
        for i, xi in enumerate(x):
            result[i] = self.process_sample(int(xi))
        return result


class FilterBank:
    """
    Multi-band filter bank for EEG feature extraction
    Typical bands: mu (8-13 Hz), beta (13-30 Hz), gamma (30-80 Hz)
    """
    
    def __init__(self, fs: float = 250.0):
        self.fs = fs
        self.bands = {}
        
        # Standard EEG bands
        self.add_band('mu', 8, 13)
        self.add_band('beta', 13, 30)
        self.add_band('gamma', 30, 80)
    
    def add_band(self, name: str, low: float, high: float, order: int = 4):
        """Add a frequency band"""
        self.bands[name] = BandpassBiquad(low, high, self.fs, order)
    
    def reset(self):
        """Reset all bands"""
        for filt in self.bands.values():
            filt.reset()
    
    def process(self, x: np.ndarray) -> dict:
        """Process through all bands, return dict of band outputs"""
        return {name: filt.process(x) for name, filt in self.bands.items()}
    
    def process_sample(self, x: int) -> dict:
        """Process single sample through all bands"""
        return {name: filt.process_sample(x) for name, filt in self.bands.items()}


class ConditioningChain:
    """
    Complete conditioning chain: DC blocker → Notch → Bandpass
    """
    
    def __init__(self, fs: float = 250.0, notch_freq: float = 60.0,
                 bandpass: Tuple[float, float] = (8, 30)):
        """
        Args:
            fs: Sampling rate (Hz)
            notch_freq: Line frequency to notch (50 or 60 Hz)
            bandpass: (low, high) cutoff frequencies
        """
        self.fs = fs
        self.dc_blocker = DCBlocker(alpha=0.995, fs=fs)
        self.notch = BiquadNotch(notch_freq, fs, Q=30.0)
        self.bandpass = BandpassBiquad(bandpass[0], bandpass[1], fs, order=4)
    
    def reset(self):
        """Reset all stages"""
        self.dc_blocker.reset()
        self.notch.reset()
        self.bandpass.reset()
    
    def process_sample(self, x: int) -> int:
        """Process single sample through chain"""
        y = self.dc_blocker.process_sample(x)
        y = self.notch.process_sample(y)
        y = self.bandpass.process_sample(y)
        return y
    
    def process(self, x: np.ndarray) -> np.ndarray:
        """Process array through chain"""
        y = self.dc_blocker.process(x)
        y = self.notch.process(y)
        y = self.bandpass.process(y)
        return y


def create_eeg_conditioning(fs: float = 250.0, line_freq: float = 60.0) -> ConditioningChain:
    """Factory for standard EEG conditioning chain"""
    return ConditioningChain(fs=fs, notch_freq=line_freq, bandpass=(8, 30))
