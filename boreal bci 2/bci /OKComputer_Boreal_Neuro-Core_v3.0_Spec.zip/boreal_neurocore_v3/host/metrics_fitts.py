"""
Boreal Neuro-Core v3.0 - Fitts' Law Metrics
Standardized evaluation for pointing device performance

Fitts' Law: MT = a + b * log2(A/W + 1)
Throughput = log2(A/W + 1) / MT (bits/second)
"""

import numpy as np
from typing import List, Tuple, Dict
from dataclasses import dataclass
from collections import defaultdict


@dataclass
class FittsTask:
    """Single Fitts' law trial"""
    target_x: float
    target_y: float
    target_w: float  # Target width
    start_x: float
    start_y: float
    
    @property
    def amplitude(self) -> float:
        """Movement amplitude (distance)"""
        return np.sqrt(
            (self.target_x - self.start_x)**2 +
            (self.target_y - self.start_y)**2
        )
    
    @property
    def index_of_difficulty(self) -> float:
        """ID = log2(A/W + 1)"""
        return np.log2(self.amplitude / self.target_w + 1)


@dataclass
class FittsResult:
    """Result of a completed trial"""
    task: FittsTask
    movement_time: float  # seconds
    path_length: float    # total path distance
    success: bool
    overshoots: int
    final_error: float    # distance from target center


class FittsEvaluator:
    """
    Evaluate control performance using Fitts' Law
    """
    
    def __init__(self):
        self.results: List[FittsResult] = []
        self.current_trial: FittsTask = None
        self.trial_start_time: float = None
        self.trial_positions: List[Tuple[float, float]] = []
    
    def start_trial(self, task: FittsTask, timestamp: float):
        """Begin a new trial"""
        self.current_trial = task
        self.trial_start_time = timestamp
        self.trial_positions = [(task.start_x, task.start_y)]
    
    def update_position(self, x: float, y: float, timestamp: float):
        """Record position during trial"""
        if self.current_trial is not None:
            self.trial_positions.append((x, y))
    
    def end_trial(self, success: bool, timestamp: float) -> FittsResult:
        """Complete current trial"""
        if self.current_trial is None:
            return None
        
        movement_time = timestamp - self.trial_start_time
        
        # Compute path metrics
        positions = np.array(self.trial_positions)
        path_length = 0.0
        for i in range(1, len(positions)):
            dx = positions[i, 0] - positions[i-1, 0]
            dy = positions[i, 1] - positions[i-1, 1]
            path_length += np.sqrt(dx**2 + dy**2)
        
        # Count overshoots (cross target boundary and exit)
        overshoots = self._count_overshoots(positions)
        
        # Final error
        final_pos = positions[-1]
        final_error = np.sqrt(
            (final_pos[0] - self.current_trial.target_x)**2 +
            (final_pos[1] - self.current_trial.target_y)**2
        )
        
        result = FittsResult(
            task=self.current_trial,
            movement_time=movement_time,
            path_length=path_length,
            success=success,
            overshoots=overshoots,
            final_error=final_error
        )
        
        self.results.append(result)
        self.current_trial = None
        
        return result
    
    def _count_overshoots(self, positions: np.ndarray) -> int:
        """Count target boundary crossings"""
        if len(positions) < 2:
            return 0
        
        tx, ty = self.current_trial.target_x, self.current_trial.target_y
        tw = self.current_trial.target_w
        
        # Distance from target center at each point
        dists = np.sqrt((positions[:, 0] - tx)**2 + (positions[:, 1] - ty)**2)
        
        # Inside target = distance < W/2
        inside = dists < tw / 2
        
        # Count transitions from inside to outside
        overshoots = 0
        for i in range(1, len(inside)):
            if inside[i-1] and not inside[i]:
                overshoots += 1
        
        return overshoots
    
    def compute_throughput(self) -> Dict[str, float]:
        """
        Compute Fitts' throughput and regression parameters
        
        Returns:
            Dictionary with throughput metrics
        """
        if len(self.results) == 0:
            return {'throughput': 0.0}
        
        # Filter successful trials
        successful = [r for r in self.results if r.success]
        
        if len(successful) < 3:
            return {'throughput': 0.0, 'n_successful': len(successful)}
        
        # Extract IDs and MTs
        ids = np.array([r.task.index_of_difficulty for r in successful])
        mts = np.array([r.movement_time for r in successful])
        
        # Linear regression: MT = a + b * ID
        A = np.vstack([np.ones_like(ids), ids]).T
        a, b = np.linalg.lstsq(A, mts, rcond=None)[0]
        
        # Throughput = 1/b (bits/second)
        throughput = 1.0 / b if b > 0 else 0.0
        
        # Effective throughput (ID/MT for each trial)
        effective_tp = ids / mts
        
        return {
            'throughput': throughput,
            'throughput_std': np.std(effective_tp),
            'intercept_a': a,
            'slope_b': b,
            'r_squared': self._compute_r_squared(ids, mts, a, b),
            'n_trials': len(self.results),
            'n_successful': len(successful),
            'mean_mt': np.mean(mts),
            'mean_id': np.mean(ids)
        }
    
    def _compute_r_squared(self, x: np.ndarray, y: np.ndarray, 
                          a: float, b: float) -> float:
        """Compute R-squared for linear fit"""
        y_pred = a + b * x
        ss_res = np.sum((y - y_pred)**2)
        ss_tot = np.sum((y - np.mean(y))**2)
        return 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    
    def compute_path_metrics(self) -> Dict[str, float]:
        """Compute path efficiency metrics"""
        if len(self.results) == 0:
            return {}
        
        successful = [r for r in self.results if r.success]
        
        if len(successful) == 0:
            return {}
        
        path_efficiencies = []
        for r in successful:
            if r.task.amplitude > 0:
                eff = r.task.amplitude / r.path_length
                path_efficiencies.append(eff)
        
        return {
            'mean_path_efficiency': np.mean(path_efficiencies),
            'std_path_efficiency': np.std(path_efficiencies),
            'mean_overshoots': np.mean([r.overshoots for r in successful]),
            'mean_final_error': np.mean([r.final_error for r in successful])
        }
    
    def get_summary(self) -> Dict[str, any]:
        """Get complete summary"""
        throughput = self.compute_throughput()
        path = self.compute_path_metrics()
        
        return {
            'throughput': throughput,
            'path': path,
            'success_rate': len([r for r in self.results if r.success]) / max(len(self.results), 1)
        }


class RadialFittsTask:
    """
    Generate standard radial Fitts' task
    Targets arranged in circle at varying distances and widths
    """
    
    def __init__(self, center: Tuple[float, float] = (512, 384),
                 amplitudes: List[float] = None,
                 widths: List[float] = None):
        self.center = center
        self.amplitudes = amplitudes or [128, 256, 512]
        self.widths = widths or [32, 64, 128]
    
    def generate_sequence(self, n_repetitions: int = 3) -> List[FittsTask]:
        """Generate trial sequence"""
        tasks = []
        
        for _ in range(n_repetitions):
            for A in self.amplitudes:
                for W in self.widths:
                    # Random angle
                    angle = np.random.uniform(0, 2 * np.pi)
                    
                    target_x = self.center[0] + A * np.cos(angle)
                    target_y = self.center[1] + A * np.sin(angle)
                    
                    # Start from center
                    task = FittsTask(
                        target_x=target_x,
                        target_y=target_y,
                        target_w=W,
                        start_x=self.center[0],
                        start_y=self.center[1]
                    )
                    tasks.append(task)
        
        # Shuffle
        np.random.shuffle(tasks)
        
        return tasks


def run_fitts_evaluation(control_system, 
                         n_trials: int = 27,
                         screen_size: Tuple[int, int] = (1024, 768)) -> Dict:
    """
    Run complete Fitts' evaluation
    
    Args:
        control_system: Callable that takes (target_x, target_y) and returns position
        n_trials: Number of trials
        screen_size: Screen dimensions
    
    Returns:
        Evaluation summary
    """
    evaluator = FittsEvaluator()
    task_gen = RadialFittsTask(
        center=(screen_size[0]/2, screen_size[1]/2)
    )
    
    tasks = task_gen.generate_sequence(n_repetitions=n_trials // 9)
    
    for task in tasks:
        # Start trial
        evaluator.start_trial(task, timestamp=0.0)
        
        # Simulate movement (placeholder)
        # In real system, this would integrate with actual control
        current_pos = (task.start_x, task.start_y)
        
        for t in range(100):  # 100 time steps
            # Update position using control system
            # current_pos = control_system(task.target_x, task.target_y)
            evaluator.update_position(current_pos[0], current_pos[1], timestamp=t*0.008)
        
        # End trial
        success = True  # Determine based on final position
        evaluator.end_trial(success, timestamp=100*0.008)
    
    return evaluator.get_summary()
