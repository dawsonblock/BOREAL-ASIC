"""
Boreal Neuro-Core v3.0 - Calibration & Training Pipeline
Phase 1-3: Data collection, training, closed-loop adaptation
"""

import numpy as np
from typing import Tuple, List, Dict, Optional
from dataclasses import dataclass
from pathlib import Path
import json


@dataclass
class CalibrationConfig:
    """Calibration protocol configuration"""
    fs: float = 250.0
    n_channels: int = 16
    rest_duration_s: float = 60.0
    task_duration_s: float = 300.0
    bands: List[str] = None
    
    def __post_init__(self):
        if self.bands is None:
            self.bands = ['mu', 'beta']


class DataCollector:
    """
    Phase 1: Data collection for calibration
    Records resting baseline and intentional movement tasks
    """
    
    def __init__(self, config: CalibrationConfig = None):
        self.cfg = config or CalibrationConfig()
        self.rest_data = None
        self.task_data = None
        self.labels = None
    
    def collect_rest(self, duration_s: float = None) -> np.ndarray:
        """
        Collect resting baseline data
        
        Returns:
            (n_channels, n_samples) array
        """
        duration = duration_s or self.cfg.rest_duration_s
        n_samples = int(duration * self.cfg.fs)
        
        # Placeholder: in real system, this comes from EEG hardware
        # Generate synthetic data for testing
        data = np.random.randn(self.cfg.n_channels, n_samples) * 10.0
        
        self.rest_data = data
        return data
    
    def collect_task(self, duration_s: float = None,
                     target_pattern: str = 'cursor_2d') -> Tuple[np.ndarray, np.ndarray]:
        """
        Collect task data with known targets
        
        Args:
            duration_s: Collection duration
            target_pattern: Type of task ('cursor_2d', 'discrete', etc.)
        
        Returns:
            (data, labels) tuple
        """
        duration = duration_s or self.cfg.task_duration_s
        n_samples = int(duration * self.cfg.fs)
        
        # Placeholder: synthetic data with some structure
        data = np.random.randn(self.cfg.n_channels, n_samples) * 15.0
        
        # Generate target labels (2D velocity)
        if target_pattern == 'cursor_2d':
            # Random target sequence
            n_targets = int(duration / 5.0)  # 5s per target
            labels = np.zeros((n_samples, 2))
            
            for i in range(n_targets):
                start = int(i * 5.0 * self.cfg.fs)
                end = min(int((i + 1) * 5.0 * self.cfg.fs), n_samples)
                
                # Random direction
                angle = np.random.uniform(0, 2 * np.pi)
                vel = np.array([np.cos(angle), np.sin(angle)]) * 10.0
                labels[start:end, :] = vel
        else:
            labels = np.zeros((n_samples, 2))
        
        self.task_data = data
        self.labels = labels
        
        return data, labels
    
    def save(self, path: str):
        """Save collected data"""
        np.savez(path,
                 rest=self.rest_data,
                 task=self.task_data,
                 labels=self.labels,
                 config=self.cfg)
    
    @classmethod
    def load(cls, path: str) -> 'DataCollector':
        """Load collected data"""
        data = np.load(path, allow_pickle=True)
        config = data['config'].item()
        
        collector = cls(config)
        collector.rest_data = data['rest']
        collector.task_data = data['task']
        collector.labels = data['labels']
        
        return collector


class FeatureExtractor:
    """
    Extract bandpower features from raw EEG
    """
    
    def __init__(self, fs: float = 250.0, n_channels: int = 16):
        self.fs = fs
        self.n_channels = n_channels
        
        # Import from twin
        from ..twin.filters import FilterBank
        from ..twin.bandpower import MultiChannelBandpower, BandpowerConfig
        
        self.filter_bank = FilterBank(fs)
        
        config = BandpowerConfig(
            window_ms=128.0,
            update_ms=8.0,
            alpha=0.95,
            fs=fs
        )
        self.bandpower = MultiChannelBandpower(n_channels, ['mu', 'beta'], config)
    
    def extract(self, data: np.ndarray) -> np.ndarray:
        """
        Extract features from raw data
        
        Args:
            data: (n_channels, n_samples) raw EEG
        
        Returns:
            (n_features, n_windows) feature matrix
        """
        # Process through filter bank
        features_list = []
        
        window_size = int(128 * self.fs / 1000)  # 128ms
        update_size = int(8 * self.fs / 1000)    # 8ms
        
        n_samples = data.shape[1]
        n_windows = (n_samples - window_size) // update_size
        
        for i in range(n_windows):
            start = i * update_size
            end = start + window_size
            
            window = data[:, start:end]
            
            # Filter each channel
            band_outputs = {}
            for band_name in ['mu', 'beta']:
                filt = self.filter_bank.bands[band_name]
                filtered = np.zeros_like(window)
                for ch in range(self.n_channels):
                    filtered[ch, :] = filt.process(window[ch, :])
                band_outputs[band_name] = filtered
            
            # Extract features
            feats = self.bandpower.process_frame(band_outputs)
            if feats is not None:
                features_list.append(feats)
        
        return np.array(features_list)
    
    def extract_with_labels(self, data: np.ndarray, 
                           labels: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        Extract features aligned with labels
        
        Returns:
            (features, labels) aligned
        """
        features = self.extract(data)
        
        # Downsample labels to feature rate
        window_size = int(128 * self.fs / 1000)
        update_size = int(8 * self.fs / 1000)
        
        n_features = features.shape[0]
        labels_down = np.zeros((n_features, labels.shape[1]))
        
        for i in range(n_features):
            start = i * update_size + window_size // 2
            end = start + update_size
            if end < labels.shape[0]:
                labels_down[i, :] = np.mean(labels[start:end, :], axis=0)
        
        return features, labels_down


class Calibrator:
    """
    Complete calibration pipeline
    """
    
    def __init__(self, config: CalibrationConfig = None):
        self.cfg = config or CalibrationConfig()
        self.collector = DataCollector(self.cfg)
        self.extractor = FeatureExtractor(self.cfg.fs, self.cfg.n_channels)
        
        self.decoder = None
        self.metrics = {}
    
    def run_phase1_collect(self) -> dict:
        """Phase 1: Data collection"""
        print("Phase 1: Data Collection")
        print(f"  Collecting rest baseline ({self.cfg.rest_duration_s}s)...")
        self.collector.collect_rest()
        
        print(f"  Collecting task data ({self.cfg.task_duration_s}s)...")
        self.collector.collect_task()
        
        return {
            'rest_shape': self.collector.rest_data.shape if self.collector.rest_data is not None else None,
            'task_shape': self.collector.task_data.shape if self.collector.task_data is not None else None
        }
    
    def run_phase2_train(self, lambda_reg: float = 0.01) -> dict:
        """Phase 2: Train decoder"""
        print("Phase 2: Training")
        
        # Extract features
        print("  Extracting features...")
        features, labels = self.extractor.extract_with_labels(
            self.collector.task_data,
            self.collector.labels
        )
        
        print(f"  Features: {features.shape}, Labels: {labels.shape}")
        
        # Train decoder
        from ..twin.decoder import train_decoder_from_data
        
        print("  Training ridge regression decoder...")
        self.decoder, metrics = train_decoder_from_data(
            features, labels,
            lambda_reg=lambda_reg
        )
        
        self.metrics['training'] = metrics
        print(f"  Training RMSE: {metrics['rmse']:.3f}, R2: {metrics['r2']:.3f}")
        
        return metrics
    
    def run_phase3_validate(self, n_trials: int = 10) -> dict:
        """Phase 3: Validation (placeholder for closed-loop)"""
        print("Phase 3: Validation")
        print(f"  Running {n_trials} validation trials...")
        
        # Placeholder: would run actual closed-loop task
        metrics = {
            'trials': n_trials,
            'success_rate': 0.8,
            'mean_time_to_target': 2.5
        }
        
        self.metrics['validation'] = metrics
        return metrics
    
    def save(self, path: str):
        """Save calibration results"""
        output_path = Path(path)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Save data
        self.collector.save(str(output_path / 'data.npz'))
        
        # Save decoder
        if self.decoder is not None:
            self.decoder.save(str(output_path / 'decoder.npz'))
        
        # Save metrics
        with open(output_path / 'metrics.json', 'w') as f:
            json.dump(self.metrics, f, indent=2)
    
    def export_for_fpga(self, output_dir: str) -> dict:
        """Export trained system for FPGA"""
        from ..twin.kalman import KalmanCore, KalmanConfig
        from ..twin.quantize_to_fpga import export_full_system
        
        # Create Kalman with default config
        kalman = KalmanCore(KalmanConfig(dt=0.008))
        
        return export_full_system(
            kalman,
            self.decoder,
            output_dir
        )


def quick_calibrate(data_path: str = None, 
                   output_dir: str = None) -> Calibrator:
    """
    Run quick calibration (synthetic data for testing)
    
    Args:
        data_path: Path to save/load data
        output_dir: Directory for FPGA exports
    
    Returns:
        Calibrator instance
    """
    config = CalibrationConfig(
        fs=250.0,
        n_channels=16,
        rest_duration_s=10.0,  # Short for testing
        task_duration_s=60.0
    )
    
    cal = Calibrator(config)
    
    # Phase 1
    cal.run_phase1_collect()
    
    # Phase 2
    cal.run_phase2_train(lambda_reg=0.01)
    
    # Phase 3
    cal.run_phase3_validate(n_trials=5)
    
    # Save
    if data_path:
        cal.save(data_path)
    
    # Export
    if output_dir:
        result = cal.export_for_fpga(output_dir)
        print(f"Exported to: {output_dir}")
        print(f"  JSON: {result['json_path']}")
        print(f"  MEM files: {len(result['mem_files'])}")
    
    return cal
