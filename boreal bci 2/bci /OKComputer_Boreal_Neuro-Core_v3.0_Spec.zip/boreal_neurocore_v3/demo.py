"""
Boreal Neuro-Core v3.0 - Demonstration Script
Complete end-to-end simulation of the neural control system
"""

import numpy as np
import time
from pathlib import Path

from twin import (
    FixedPoint, FMT_SAMPLE, FMT_STATE,
    ConditioningChain, create_eeg_conditioning,
    MultiChannelBandpower, create_standard_bandpower,
    LinearDecoder, DecoderConfig, LMSAdaptiveDecoder,
    KalmanCore, KalmanConfig, PredictiveController,
    SafetyGate, GateConfig, ConfidenceEstimator,
    TimingEmulator, create_default_timing, create_wireless_timing,
    export_full_system
)


class BorealSimulator:
    """
    Complete system simulator
    """
    
    def __init__(self, 
                 n_channels: int = 16,
                 fs: float = 250.0,
                 timing_config=None):
        
        self.n_channels = n_channels
        self.fs = fs
        
        print(f"Initializing Boreal Neuro-Core v3.0 Simulator")
        print(f"  Channels: {n_channels}")
        print(f"  Sampling rate: {fs} Hz")
        
        # Signal conditioning
        self.conditioning = [
            create_eeg_conditioning(fs) for _ in range(n_channels)
        ]
        
        # Feature extraction
        self.feature_extractor = create_standard_bandpower(n_channels, fs)
        self.normalizer = None  # Created after first features
        
        # Decoder (placeholder - trained later)
        self.decoder = None
        self.adaptive_decoder = None
        
        # Control
        self.controller = PredictiveController(dt=0.008, max_delay_ms=60.0)
        
        # Safety gate
        self.gate = SafetyGate(GateConfig())
        self.confidence_est = ConfidenceEstimator(n_channels * 3)  # 3 bands
        
        # Timing
        self.timing = TimingEmulator(timing_config or create_default_timing())
        
        # State
        self.cursor_pos = np.array([512.0, 384.0])  # Screen center
        self.is_running = False
        
        # Logging
        self.log = []
    
    def train_decoder(self, features: np.ndarray, targets: np.ndarray):
        """Train the neural decoder"""
        print("\nTraining decoder...")
        
        config = DecoderConfig(
            n_features=features.shape[1],
            n_outputs=2,
            lambda_reg=0.01
        )
        
        self.decoder = LinearDecoder(config)
        metrics = self.decoder.train(features, targets)
        
        print(f"  RMSE: {metrics['rmse']:.4f}")
        print(f"  R²: {metrics['r2']:.4f}")
        
        # Create adaptive version
        self.adaptive_decoder = LMSAdaptiveDecoder(
            config.n_features, config.n_outputs, mu=0.001
        )
        self.adaptive_decoder.W = self.decoder.W.copy()
        self.adaptive_decoder.b = self.decoder.b.copy()
        
        # Normalizer is part of feature extractor
        # (bandpower includes running statistics)
        
        return metrics
    
    def process_frame(self, eeg_frame: np.ndarray) -> dict:
        """
        Process one frame of EEG data
        
        Args:
            eeg_frame: (n_channels, n_samples) raw EEG
        
        Returns:
            Control output dict
        """
        # 1. Signal conditioning
        conditioned = np.zeros_like(eeg_frame)
        for ch in range(self.n_channels):
            conditioned[ch, :] = self.conditioning[ch].process(eeg_frame[ch, :])
        
        # 2. Feature extraction
        # Filter into bands
        from twin.filters import FilterBank
        filter_bank = FilterBank(self.fs)
        
        band_data = {}
        for band_name in ['mu', 'beta', 'gamma']:
            filt = filter_bank.bands[band_name]
            filtered = np.zeros_like(conditioned)
            for ch in range(self.n_channels):
                filtered[ch, :] = filt.process(conditioned[ch, :])
            band_data[band_name] = filtered
        
        # Extract bandpower
        features = self.feature_extractor.process_frame(band_data)
        
        if features is None:
            return None
        
        # 3. Decode
        if self.decoder is None:
            return None
        
        # Features are already Q4.12 from bandpower, convert to Q1.15
        # by shifting left 3 bits (multiply by 8)
        features_q = np.array(features, dtype=np.int32) << 3
        features_q = np.clip(features_q, -32768, 32767).astype(np.int16)
        
        # Decode (fixed-point)
        u_q = self.decoder.decode_fixed(features_q)
        u = FixedPoint(FMT_STATE).from_fixed(u_q)
        
        # 4. Confidence estimation
        conf = self.confidence_est.update(
            features.astype(float),
            kalman_innovation=0.5,
            artifact_detected=False
        )
        conf_q = int(conf * 32767)
        
        # 5. Safety gate
        u_gated, click = self.gate.gate_fixed(u_q, conf_q)
        u_gated_f = FixedPoint(FMT_STATE).from_fixed(u_gated)
        
        # 6. Predictive control
        x_pred = self.controller.process_fixed(u_gated)
        pos = x_pred[:2]
        vel = x_pred[2:]
        
        # Update cursor
        self.cursor_pos = FixedPoint(FMT_STATE).from_fixed(pos)
        
        return {
            'position': self.cursor_pos.copy(),
            'velocity': FixedPoint(FMT_STATE).from_fixed(vel),
            'confidence': conf,
            'click': click,
            'features': features
        }
    
    def run_simulation(self, duration_s: float = 10.0) -> list:
        """Run simplified simulation (decoder only)"""
        print(f"\nRunning simulation for {duration_s}s...")
        
        # Simplified: just generate features and decode
        n_outputs = int(duration_s / 0.008)  # One output per 8ms tick
        
        outputs = []
        for i in range(n_outputs):
            # Generate synthetic features
            features = np.random.randn(48) * 100.0  # 16 ch * 3 bands
            features_q = FixedPoint(FMT_SAMPLE).to_fixed(features)
            
            # Decode
            u_q = self.decoder.decode_fixed(features_q)
            u = FixedPoint(FMT_STATE).from_fixed(u_q)
            
            # Confidence
            conf = 0.5 + 0.3 * np.sin(i * 0.1)
            conf_q = int(conf * 32767)
            
            # Gate
            u_gated, click = self.gate.gate_fixed(u_q, conf_q)
            
            # Update cursor
            self.cursor_pos += FixedPoint(FMT_STATE).from_fixed(u_gated) * 0.008
            
            outputs.append({
                'position': self.cursor_pos.copy(),
                'velocity': FixedPoint(FMT_STATE).from_fixed(u_gated),
                'confidence': conf,
                'click': click
            })
        
        print(f"  Generated {len(outputs)} control outputs")
        
        return outputs
    
    def export_system(self, output_dir: str):
        """Export trained system for FPGA"""
        if self.decoder is None:
            print("Error: Decoder not trained")
            return
        
        print(f"\nExporting to {output_dir}...")
        
        result = export_full_system(
            self.controller.kalman,
            self.decoder,
            output_dir
        )
        
        print(f"  JSON: {result['json_path']}")
        print(f"  MEM files: {len(result['mem_files'])}")
        print(f"  Verilog: {result['verilog_path']}")
        
        return result


def demo_quick_start():
    """Quick demonstration"""
    print("\n" + "=" * 60)
    print("BOREAL NEURO-CORE v3.0 - QUICK START DEMO")
    print("=" * 60)
    
    # Create simulator
    sim = BorealSimulator(
        n_channels=16,
        fs=250.0,
        timing_config=create_default_timing()
    )
    
    # Generate synthetic training data
    print("\nGenerating training data...")
    n_train = 1000
    n_features = 48  # 16 channels * 3 bands
    
    # Features with some correlation to targets
    features = np.random.randn(n_train, n_features)
    
    # Targets: 2D velocity with some structure
    angle = np.linspace(0, 4*np.pi, n_train)
    targets = np.column_stack([
        10.0 * np.cos(angle),
        10.0 * np.sin(angle)
    ])
    # Add correlation to features
    targets += features[:, :2] * 2.0
    targets += np.random.randn(n_train, 2) * 1.0
    
    # Train
    sim.train_decoder(features, targets)
    
    # Run simulation
    outputs = sim.run_simulation(duration_s=5.0)
    
    # Analyze
    if outputs:
        positions = np.array([o['position'] for o in outputs])
        velocities = np.array([o['velocity'] for o in outputs])
        confidences = [o['confidence'] for o in outputs]
        clicks = sum(o['click'] for o in outputs)
        
        print("\nSimulation Results:")
        print(f"  Position range: X=[{positions[:,0].min():.1f}, {positions[:,0].max():.1f}], "
              f"Y=[{positions[:,1].min():.1f}, {positions[:,1].max():.1f}]")
        print(f"  Mean velocity: {np.mean(np.linalg.norm(velocities, axis=1)):.2f}")
        print(f"  Mean confidence: {np.mean(confidences):.3f}")
        print(f"  Clicks detected: {clicks}")
    
    # Export
    output_dir = Path(__file__).parent / "demo_output"
    output_dir.mkdir(exist_ok=True)
    sim.export_system(str(output_dir))
    
    print("\n" + "=" * 60)
    print("DEMO COMPLETE")
    print("=" * 60)
    print(f"\nOutputs saved to: {output_dir}")


def demo_timing_comparison():
    """Compare timing configurations"""
    print("\n" + "=" * 60)
    print("TIMING CONFIGURATION COMPARISON")
    print("=" * 60)
    
    configs = {
        'Wired (Low Latency)': create_wireless_timing(),
        'Default': create_default_timing(),
        'Wireless (High Jitter)': create_wireless_timing()
    }
    
    for name, config in configs.items():
        print(f"\n{name}:")
        print(f"  Tick: {config.tick_ms}ms")
        print(f"  Nominal delay: {config.nominal_delay_ms}ms")
        print(f"  Jitter: {config.jitter_ms}ms")
        print(f"  Buffer depth: {config.buffer_depth}")


if __name__ == "__main__":
    demo_quick_start()
    demo_timing_comparison()
