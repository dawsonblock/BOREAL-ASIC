/*
 * Boreal VNS Controller v1.0
 * Generates a specific Burst-Mode Pulse Train for Vagus Nerve Stimulation.
 * Syncs with the Adaptive PLL for Phase-Locked Cardiac/Respiratory triggering.
 */

module boreal_vns_control (
    input  wire clk_100m,
    input  wire rst_n,
    input  wire trigger_in,     // From Adaptive PLL (Peak of R-wave or Exhale)
    input  wire [7:0] intensity, // 0-255 scaling for pulse width
    
    output reg  stim_out,       // Physical output to VNS electrode driver
    output reg  safety_active   // High if stimulation exceeds safe duty cycle
);

    // VNS Pulse Parameters (Typically 20-30Hz bursts)
    localparam PULSE_WIDTH = 50000;  // 500us at 100MHz
    localparam BURST_COUNT = 15;     // Number of pulses per trigger event

    reg [31:0] timer;
    reg [7:0]  pulse_idx;
    reg        is_bursting;
    reg [31:0] global_safety_timer;

    always @(posedge clk_100m or negedge rst_n) begin
        if (!rst_n) begin
            timer <= 0;
            pulse_idx <= 0;
            is_bursting <= 0;
            stim_out <= 0;
            safety_active <= 0;
            global_safety_timer <= 0;
        end else begin
            // Safety: Ensure we don't stimulate more than 10% of the time
            if (stim_out) global_safety_timer <= global_safety_timer + 1;
            else if (global_safety_timer > 0) global_safety_timer <= global_safety_timer - 1;
            
            safety_active <= (global_safety_timer > 100000000); // 1 second total stim/10sec

            // Trigger Burst
            if (trigger_in && !is_bursting && !safety_active) begin
                is_bursting <= 1;
                timer <= 0;
                pulse_idx <= 0;
            end

            if (is_bursting) begin
                timer <= timer + 1;
                
                // Generate 25Hz pulses (40ms period)
                // Intensity controls the 'ON' time within each pulse
                if (timer < (intensity * 100)) begin
                    stim_out <= 1;
                end else if (timer < 4000000) begin // 40ms pulse period
                    stim_out <= 0;
                end else begin
                    timer <= 0;
                    pulse_idx <= pulse_idx + 1;
                    if (pulse_idx >= BURST_COUNT) begin
                        is_bursting <= 0;
                        stim_out <= 0;
                    end
                end
            end
        end
    end
endmodule
