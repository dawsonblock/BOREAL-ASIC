/*
 * Boreal Neuro-Core v2.4 (Corrected Build)
 * Key Features:
 * 1. DC-Blocking High Pass Filter (Pre-Inference)
 * 2. Saturation Arithmetic (Anti-Overflow)
 * 3. Systolic Array Active Inference Engine
 * 4. Pipelined PWM Integration
 */

module boreal_apex_core #(
    parameter ADDR_WIDTH = 10,
    parameter CHANNELS   = 8,
    parameter ALPHA      = 16'h7EB8 // 0.99 for DC Blocking Filter
)(
    input  wire        clk,
    input  wire        rst_n,
    input  wire        emergency_halt_n, // Physical override (Bite-switch)

    // ADS1299 Interface (Simplified)
    input  wire [23:0] raw_adc_in,
    input  wire [2:0]  adc_channel_sel,
    input  wire        adc_data_ready,

    // Motor/Stim Control
    output reg  [7:0]  pwm_out,
    output wire signed [15:0] filtered_sample // Exposed for PLL
);

    // --- 1. DC-BLOCKING FILTER & TRUNCATION ---
    // Formula: y[n] = x[n] - x[n-1] + alpha * y[n-1]
    reg  signed [23:0] last_raw_x [0:CHANNELS-1];
    reg  signed [31:0] filter_acc [0:CHANNELS-1];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (integer i=0; i<CHANNELS; i=i+1) begin
                last_raw_x[i] <= 24'd0;
                filter_acc[i] <= 32'd0;
            end
        end else if (adc_data_ready) begin
            // IIR High Pass Filter logic
            filter_acc[adc_channel_sel] <= ($signed(raw_adc_in) - last_raw_x[adc_channel_sel]) + 
                                           ((filter_acc[adc_channel_sel] * $signed(ALPHA)) >>> 15);
            last_raw_x[adc_channel_sel] <= $signed(raw_adc_in);
        end
    end
    
    // Final output truncated to the 16-bit inference range
    assign filtered_sample = filter_acc[adc_channel_sel][31:16];


    // --- 2. DUAL-PORT BRAM LUT (Sigma and Sigma') ---
    wire [31:0] lut_data;
    reg  [ADDR_WIDTH-1:0] lut_addr;
    
    // Memory Instantiation
    boreal_memory #(
        .ADDR_WIDTH(ADDR_WIDTH),
        .DATA_WIDTH(32)
    ) memory_inst (
        .clk(clk),
        .addr_a(lut_addr),
        .dout_a(lut_data),
        .we_b(1'b0), // Learning engine not connected in this simplified core
        .addr_b({ADDR_WIDTH{1'b0}}),
        .din_b(32'd0),
        .dout_b()
    );


    // --- 3. ACTIVE INFERENCE ENGINE (MACC with Saturation) ---
    reg signed [15:0] mu [0:CHANNELS-1];     // Internal State
    reg signed [15:0] epsilon [0:CHANNELS-1]; // Prediction Error

    localparam signed MAX_VAL = 16'h7FFF;
    localparam signed MIN_VAL = 16'h8000;

    // Gradient Update: mu = mu + eta*(epsilon * deriv - lambda*mu)
    // eta and lambda are implemented as bit-shifts for latency closure
    wire signed [31:0] grad_product = epsilon[adc_channel_sel] * $signed(lut_data[31:16]); // eps * sigma'
    wire signed [15:0] decay = mu[adc_channel_sel] >>> 4; // lambda = 1/16

    always @(posedge clk) begin
        if (!emergency_halt_n) begin
            for (integer i=0; i<CHANNELS; i=i+1) mu[i] <= 16'd0;
        end else if (adc_data_ready) begin
            // Prediction Error: y - sigma(W*mu)
            epsilon[adc_channel_sel] <= filtered_sample - $signed(lut_data[15:0]);
            
            // Saturation Arithmetic on State Update
            if (grad_product[31:16] > MAX_VAL) 
                mu[adc_channel_sel] <= MAX_VAL;
            else if (grad_product[31:16] < MIN_VAL)
                mu[adc_channel_sel] <= MIN_VAL;
            else
                mu[adc_channel_sel] <= mu[adc_channel_sel] + grad_product[20:5] - decay;
        end
    end


    // --- 4. INTEGRATED PWM OUTPUT ---
    reg [23:0] pwm_accumulator;
    always @(posedge clk) begin
        if (!emergency_halt_n) begin
            pwm_accumulator <= 24'd0;
            pwm_out <= 8'd0;
        end else begin
            // Integrator: PWM = Integral(mu * Kp)
            pwm_accumulator <= pwm_accumulator + $signed(mu[0]); // Using Channel 0 for main control
            pwm_out <= pwm_accumulator[23:16];
        end
    end

endmodule
